<?php
// created: 2015-09-05 13:49:15
$dictionary["anmol_Marketing_activities"]["fields"]["anmol_marketing_activities_campaigns"] = array(
    'name' => 'anmol_marketing_activities_campaigns',
    'type' => 'link',
    'relationship' => 'anmol_marketing_activities_campaigns',
    'source' => 'non-db',
    'module' => 'Campaigns',
    'bean_name' => 'Campaign',
    'side' => 'right',
    'vname' => 'LBL_ANMOL_MARKETING_ACTIVITIES_CAMPAIGNS_FROM_CAMPAIGNS_TITLE',
);
