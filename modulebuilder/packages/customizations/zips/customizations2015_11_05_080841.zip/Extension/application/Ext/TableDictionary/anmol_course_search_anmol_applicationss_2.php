<?php
//WARNING: The contents of this file are auto-generated
include('custom/metadata/anmol_course_search_anmol_applicationss_2MetaData.php');

?>