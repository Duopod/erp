<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_anmol_application_stages_1MetaData.php');

?>