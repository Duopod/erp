<?php
 // created: 2015-09-16 22:34:30
$dictionary['anmol_application_stages']['fields']['filename']['inline_edit']=true;
$dictionary['anmol_application_stages']['fields']['filename']['importable']='true';
$dictionary['anmol_application_stages']['fields']['filename']['merge_filter']='disabled';

 ?>