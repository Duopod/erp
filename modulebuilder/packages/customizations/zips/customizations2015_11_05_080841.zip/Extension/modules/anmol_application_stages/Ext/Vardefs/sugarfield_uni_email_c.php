<?php
 // created: 2015-09-16 21:49:21
$dictionary['anmol_application_stages']['fields']['uni_email_c']['inline_edit']='1';
$dictionary['anmol_application_stages']['fields']['uni_email_c']['labelValue']='University Email';

 ?>