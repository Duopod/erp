<?php
 // created: 2015-09-22 21:58:40
$dictionary['anmol_application_stages']['fields']['pendency_stage_1_dummy_c']['inline_edit']='1';
$dictionary['anmol_application_stages']['fields']['pendency_stage_1_dummy_c']['labelValue']='pendency stage 1 dummy';

 ?>