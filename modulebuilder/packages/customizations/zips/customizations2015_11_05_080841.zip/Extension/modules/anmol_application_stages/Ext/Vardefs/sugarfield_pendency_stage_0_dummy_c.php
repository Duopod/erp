<?php
 // created: 2015-09-17 16:51:01
$dictionary['anmol_application_stages']['fields']['pendency_stage_0_dummy_c']['inline_edit']='1';
$dictionary['anmol_application_stages']['fields']['pendency_stage_0_dummy_c']['labelValue']='pendency stage 0 dummy';

 ?>