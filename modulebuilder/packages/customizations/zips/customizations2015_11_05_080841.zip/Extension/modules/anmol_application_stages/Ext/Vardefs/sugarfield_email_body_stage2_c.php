<?php
 // created: 2015-09-25 11:44:40
$dictionary['anmol_application_stages']['fields']['email_body_stage2_c']['inline_edit']='';
$dictionary['anmol_application_stages']['fields']['email_body_stage2_c']['labelValue']='email body stage2';

 ?>