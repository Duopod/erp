<?php
 // created: 2015-09-17 17:10:58
$dictionary['anmol_application_stages']['fields']['pendency_stage_1_subject_du_c']['inline_edit']='1';
$dictionary['anmol_application_stages']['fields']['pendency_stage_1_subject_du_c']['labelValue']='pendency stage 1 subject du';

 ?>