<?php
 // created: 2015-09-21 09:55:43
$dictionary['anmol_application_stages']['fields']['conditional_offer_c']['inline_edit']='';
$dictionary['anmol_application_stages']['fields']['conditional_offer_c']['labelValue']='Conditional Offer?';

 ?>