<?php
 // created: 2015-09-25 12:22:43
$dictionary['anmol_application_stages']['fields']['email_subject_stage2_c']['inline_edit']='';
$dictionary['anmol_application_stages']['fields']['email_subject_stage2_c']['labelValue']='email subject stage2';

 ?>