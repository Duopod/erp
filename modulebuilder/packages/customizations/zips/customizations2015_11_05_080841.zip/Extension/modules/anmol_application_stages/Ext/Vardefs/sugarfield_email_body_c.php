<?php
 // created: 2015-09-16 21:54:18
$dictionary['anmol_application_stages']['fields']['email_body_c']['inline_edit']='1';
$dictionary['anmol_application_stages']['fields']['email_body_c']['labelValue']='Email Body';

 ?>