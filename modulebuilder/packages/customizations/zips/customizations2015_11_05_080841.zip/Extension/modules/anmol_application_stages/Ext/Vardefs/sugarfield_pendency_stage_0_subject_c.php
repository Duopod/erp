<?php
 // created: 2015-09-17 17:21:23
$dictionary['anmol_application_stages']['fields']['pendency_stage_0_subject_c']['inline_edit']='1';
$dictionary['anmol_application_stages']['fields']['pendency_stage_0_subject_c']['labelValue']='pendency stage 0 subject';

 ?>