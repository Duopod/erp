<?php
 // created: 2015-09-25 00:06:20
$dictionary['anmol_application_stages']['fields']['application_stage_c']['inline_edit']='';
$dictionary['anmol_application_stages']['fields']['application_stage_c']['labelValue']='Application Stage';

 ?>