<?php
 // created: 2015-09-21 09:59:38
$dictionary['anmol_application_stages']['fields']['unchecked_docs_c']['inline_edit']='';
$dictionary['anmol_application_stages']['fields']['unchecked_docs_c']['labelValue']='Pending Docs';

 ?>