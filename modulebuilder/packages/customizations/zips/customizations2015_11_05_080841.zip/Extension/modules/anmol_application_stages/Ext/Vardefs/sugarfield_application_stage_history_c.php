<?php
 // created: 2015-09-16 15:21:32
$dictionary['anmol_application_stages']['fields']['application_stage_history_c']['inline_edit']='1';
$dictionary['anmol_application_stages']['fields']['application_stage_history_c']['labelValue']='Application History';

 ?>