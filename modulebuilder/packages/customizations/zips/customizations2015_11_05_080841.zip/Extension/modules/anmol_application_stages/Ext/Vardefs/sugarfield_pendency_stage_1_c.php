<?php
 // created: 2015-09-17 14:58:45
$dictionary['anmol_application_stages']['fields']['pendency_stage_1_c']['inline_edit']='1';
$dictionary['anmol_application_stages']['fields']['pendency_stage_1_c']['labelValue']='Enter Pendency Remark (Stg 1)';

 ?>