<?php
 // created: 2015-09-24 10:16:50
$dictionary['anmol_application_stages']['fields']['pendency_state_c']['inline_edit']='';
$dictionary['anmol_application_stages']['fields']['pendency_state_c']['labelValue']='pendency state';

 ?>