<?php
 // created: 2015-09-17 17:22:57
$dictionary['anmol_application_stages']['fields']['pendency_stage_0_subject_du__c']['inline_edit']='1';
$dictionary['anmol_application_stages']['fields']['pendency_stage_0_subject_du__c']['labelValue']='pendency stage 0 subject du';

 ?>