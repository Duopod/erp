<?php
 // created: 2015-09-22 22:34:04
$dictionary['anmol_application_stages']['fields']['app_sent_to_uni_c']['inline_edit']='1';
$dictionary['anmol_application_stages']['fields']['app_sent_to_uni_c']['labelValue']='app sent to uni';

 ?>