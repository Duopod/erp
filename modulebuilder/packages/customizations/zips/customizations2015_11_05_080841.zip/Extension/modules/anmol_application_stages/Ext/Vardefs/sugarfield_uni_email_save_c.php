<?php
 // created: 2015-09-24 11:19:58
$dictionary['anmol_application_stages']['fields']['uni_email_save_c']['inline_edit']='';
$dictionary['anmol_application_stages']['fields']['uni_email_save_c']['labelValue']='uni email save';

 ?>