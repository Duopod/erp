<?php
 // created: 2015-09-21 22:51:22
$dictionary['anmol_application_stages']['fields']['email_subject_c']['inline_edit']='1';
$dictionary['anmol_application_stages']['fields']['email_subject_c']['labelValue']='Email Subject';

 ?>