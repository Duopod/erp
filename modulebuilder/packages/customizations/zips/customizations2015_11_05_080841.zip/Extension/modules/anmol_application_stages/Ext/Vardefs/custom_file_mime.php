<?php
/**
 * Created by PhpStorm.
 * User: andy
 * Date: 14-09-2015
 * Time: 04:33
 */
$dictionary['anmol_application_stages']['fields']['file_mime_type'] = array(
    'name' => 'file_mime_type',
    'vname' => 'LBL_FILE_MIME_TYPE',
    'type' => 'varchar',
    'len' => '100',
    'importable' => false,
);