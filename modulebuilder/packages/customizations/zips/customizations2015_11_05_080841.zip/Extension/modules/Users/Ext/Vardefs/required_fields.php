<?php
$dictionary['Users']['fields']['fp_event_locations_users_1_name']['required'] = true;

?>