<?php
 // created: 2015-09-14 00:21:13
$dictionary['User']['fields']['pushbullet_token_c']['inline_edit']=1;

 ?>