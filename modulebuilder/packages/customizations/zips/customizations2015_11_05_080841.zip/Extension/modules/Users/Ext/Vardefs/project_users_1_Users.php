<?php
// created: 2014-06-20 12:06:29
$dictionary["User"]["fields"]["project_users_1"] = array(
    'name' => 'project_users_1',
    'type' => 'link',
    'relationship' => 'project_users_1',
    'source' => 'non-db',
    'module' => 'Project',
    'bean_name' => 'Project',
    'vname' => 'LBL_PROJECT_USERS_1_FROM_PROJECT_TITLE',
);
