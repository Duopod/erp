<?php
// created: 2015-08-29 17:16:19
$dictionary['User']['fields']['address_c']['inline_edit'] = '1';
$dictionary['User']['fields']['address_c']['labelValue'] = 'address';

?>