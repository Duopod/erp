﻿<?php

$mod_strings = array_merge($mod_strings,
    array(
        'LBL_LIST_NONINHERITABLE' => 'Не успадковується',
        'LBL_PRIMARY_GROUP' => 'Основной группой',
    )
);
?>
