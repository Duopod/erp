<?php
$mod_strings['LBL_PUSHBULLET_TOKEN'] = 'Pushbullet Token';
