<?php
// created: 2015-08-29 20:10:59
$dictionary['anmol_Applications']['fields']['name']['required'] = false;
$dictionary['anmol_Applications']['fields']['name']['inline_edit'] = true;
$dictionary['anmol_Applications']['fields']['name']['duplicate_merge'] = 'disabled';
$dictionary['anmol_Applications']['fields']['name']['duplicate_merge_dom_value'] = '0';
$dictionary['anmol_Applications']['fields']['name']['merge_filter'] = 'disabled';
$dictionary['anmol_Applications']['fields']['name']['unified_search'] = false;

?>