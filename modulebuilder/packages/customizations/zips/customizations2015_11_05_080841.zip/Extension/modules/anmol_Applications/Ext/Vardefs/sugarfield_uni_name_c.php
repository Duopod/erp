<?php
// created: 2015-08-29 02:15:19
$dictionary['anmol_Applications']['fields']['uni_name_c']['inline_edit'] = '1';
$dictionary['anmol_Applications']['fields']['uni_name_c']['labelValue'] = 'University';

?>