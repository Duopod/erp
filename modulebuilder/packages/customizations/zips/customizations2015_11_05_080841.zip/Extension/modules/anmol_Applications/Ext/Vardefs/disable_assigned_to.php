<?php
$dictionary['anmol_Applications']['fields']['assigned_user_name']['disabled'] = true;