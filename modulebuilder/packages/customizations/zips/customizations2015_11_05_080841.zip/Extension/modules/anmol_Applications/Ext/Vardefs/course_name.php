<?php
$dictionary['anmol_Applications']['fields']['anmol_course_search_anmol_applications_1_name']['required'] = true;
?>