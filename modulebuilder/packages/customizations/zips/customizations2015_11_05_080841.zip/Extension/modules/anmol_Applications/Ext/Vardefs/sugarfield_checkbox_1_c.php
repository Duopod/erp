<?php
// created: 2015-09-08 15:36:15
$dictionary['anmol_Applications']['fields']['checkbox_1_c']['inline_edit'] = '1';
$dictionary['anmol_Applications']['fields']['checkbox_1_c']['labelValue'] = 'checkbox 1';

?>