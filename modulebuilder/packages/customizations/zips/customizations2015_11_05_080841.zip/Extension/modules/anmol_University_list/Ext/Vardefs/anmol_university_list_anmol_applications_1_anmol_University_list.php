<?php
// created: 2015-08-28 22:42:45
$dictionary["anmol_University_list"]["fields"]["anmol_university_list_anmol_applications_1"] = array(
    'name' => 'anmol_university_list_anmol_applications_1',
    'type' => 'link',
    'relationship' => 'anmol_university_list_anmol_applications_1',
    'source' => 'non-db',
    'module' => 'anmol_Applications',
    'bean_name' => 'anmol_Applications',
    'side' => 'right',
    'vname' => 'LBL_ANMOL_UNIVERSITY_LIST_ANMOL_APPLICATIONS_1_FROM_ANMOL_APPLICATIONS_TITLE',
);
