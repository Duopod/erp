<?php
 // created: 2015-09-24 07:49:39
$dictionary['anmol_University_list']['fields']['app_phone_c']['inline_edit']='';
$dictionary['anmol_University_list']['fields']['app_phone_c']['labelValue']='Phone';

 ?>