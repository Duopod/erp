<?php
// created: 2015-09-06 11:36:18
$mod_strings['LBL_NAME'] = 'University Name';
$mod_strings['LBL_CAMPUS'] = 'Campus';
$mod_strings['LBL_SIEC_REPRESENTS'] = 'siec represents';
$mod_strings['LBL_COUNTRY'] = 'Country';

?>
