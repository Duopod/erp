<?php
 // created: 2015-09-24 07:48:15
$dictionary['anmol_University_list']['fields']['app_last_name_c']['inline_edit']='';
$dictionary['anmol_University_list']['fields']['app_last_name_c']['labelValue']='Last Name';

 ?>