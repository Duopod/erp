<?php
 // created: 2015-09-16 21:57:14
$dictionary['anmol_University_list']['fields']['uni_email_c']['inline_edit']='1';
$dictionary['anmol_University_list']['fields']['uni_email_c']['labelValue']='University Email';

 ?>