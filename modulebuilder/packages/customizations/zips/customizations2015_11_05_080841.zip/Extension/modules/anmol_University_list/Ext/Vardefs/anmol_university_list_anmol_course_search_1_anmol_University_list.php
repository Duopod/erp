<?php
// created: 2015-01-06 02:00:25
$dictionary["anmol_University_list"]["fields"]["anmol_university_list_anmol_course_search_1"] = array(
    'name' => 'anmol_university_list_anmol_course_search_1',
    'type' => 'link',
    'relationship' => 'anmol_university_list_anmol_course_search_1',
    'source' => 'non-db',
    'module' => 'anmol_course_search',
    'bean_name' => 'anmol_course_search',
    'side' => 'right',
    'vname' => 'LBL_ANMOL_UNIVERSITY_LIST_ANMOL_COURSE_SEARCH_1_FROM_ANMOL_COURSE_SEARCH_TITLE',
);
