<?php
// created: 2015-09-06 19:40:32
$dictionary['anmol_University_list']['fields']['campus_c']['inline_edit'] = 1;
$dictionary['anmol_University_list']['fields']['campus_c']['labelValue'] = 'Campus';

?>