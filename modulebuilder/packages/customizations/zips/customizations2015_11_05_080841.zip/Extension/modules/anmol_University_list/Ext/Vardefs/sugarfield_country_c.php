<?php
// created: 2015-09-06 19:40:34
$dictionary['anmol_University_list']['fields']['country_c']['inline_edit'] = 1;
$dictionary['anmol_University_list']['fields']['country_c']['labelValue'] = 'Country';

?>