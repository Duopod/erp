<?php
 // created: 2015-09-24 07:46:44
$dictionary['anmol_University_list']['fields']['app_first_name_c']['inline_edit']='';
$dictionary['anmol_University_list']['fields']['app_first_name_c']['labelValue']='First Name';

 ?>