<?php
// created: 2015-09-06 19:40:33
$dictionary['anmol_University_list']['fields']['siec_represents_c']['inline_edit'] = 1;
$dictionary['anmol_University_list']['fields']['siec_represents_c']['labelValue'] = 'siec represents';

?>