<?php
 // created: 2015-09-19 11:56:12
$dictionary['FP_Event_Locations']['fields']['branch_city_c']['inline_edit']='1';
$dictionary['FP_Event_Locations']['fields']['branch_city_c']['labelValue']='Branch City';

 ?>