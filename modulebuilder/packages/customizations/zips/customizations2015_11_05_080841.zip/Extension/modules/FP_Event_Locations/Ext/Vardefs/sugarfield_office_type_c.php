<?php
 // created: 2015-09-19 12:00:27
$dictionary['FP_Event_Locations']['fields']['office_type_c']['inline_edit']='';
$dictionary['FP_Event_Locations']['fields']['office_type_c']['labelValue']='Office Type';

 ?>