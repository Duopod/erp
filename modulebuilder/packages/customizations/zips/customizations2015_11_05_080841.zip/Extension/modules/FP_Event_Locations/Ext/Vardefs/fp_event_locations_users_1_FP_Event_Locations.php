<?php
// created: 2015-09-04 11:17:10
$dictionary["FP_Event_Locations"]["fields"]["fp_event_locations_users_1"] = array(
    'name' => 'fp_event_locations_users_1',
    'type' => 'link',
    'relationship' => 'fp_event_locations_users_1',
    'source' => 'non-db',
    'module' => 'Users',
    'bean_name' => 'User',
    'side' => 'right',
    'vname' => 'LBL_FP_EVENT_LOCATIONS_USERS_1_FROM_USERS_TITLE',
);
