<?php
 // created: 2015-09-19 12:01:41
$dictionary['FP_Event_Locations']['fields']['branch_email_c']['inline_edit']='';
$dictionary['FP_Event_Locations']['fields']['branch_email_c']['labelValue']='Branch Email';

 ?>