<?php
 // created: 2015-09-19 12:04:58
$dictionary['FP_Event_Locations']['fields']['address_postalcode']['required']=false;
$dictionary['FP_Event_Locations']['fields']['address_postalcode']['inline_edit']=true;

 ?>