<?php
 // created: 2015-09-19 12:04:40
$dictionary['FP_Event_Locations']['fields']['address_city']['required']=false;
$dictionary['FP_Event_Locations']['fields']['address_city']['inline_edit']=true;

 ?>