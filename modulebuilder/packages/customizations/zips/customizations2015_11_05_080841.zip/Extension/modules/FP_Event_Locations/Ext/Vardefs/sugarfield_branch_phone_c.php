<?php
 // created: 2015-09-19 12:02:36
$dictionary['FP_Event_Locations']['fields']['branch_phone_c']['inline_edit']='';
$dictionary['FP_Event_Locations']['fields']['branch_phone_c']['labelValue']='Branch Phone';

 ?>