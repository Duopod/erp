<?php
// created: 2015-09-04 11:42:12
$dictionary["FP_Event_Locations"]["fields"]["fp_event_locations_leads_1"] = array(
    'name' => 'fp_event_locations_leads_1',
    'type' => 'link',
    'relationship' => 'fp_event_locations_leads_1',
    'source' => 'non-db',
    'module' => 'Leads',
    'bean_name' => 'Lead',
    'side' => 'right',
    'vname' => 'LBL_FP_EVENT_LOCATIONS_LEADS_1_FROM_LEADS_TITLE',
);
