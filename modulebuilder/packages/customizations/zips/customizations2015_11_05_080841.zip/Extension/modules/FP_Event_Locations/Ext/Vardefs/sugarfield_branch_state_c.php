<?php
 // created: 2015-09-19 11:57:13
$dictionary['FP_Event_Locations']['fields']['branch_state_c']['inline_edit']='1';
$dictionary['FP_Event_Locations']['fields']['branch_state_c']['labelValue']='Branch State';

 ?>