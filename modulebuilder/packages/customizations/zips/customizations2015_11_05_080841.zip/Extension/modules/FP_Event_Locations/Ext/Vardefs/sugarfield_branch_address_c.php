<?php
 // created: 2015-09-19 11:58:22
$dictionary['FP_Event_Locations']['fields']['branch_address_c']['inline_edit']='1';
$dictionary['FP_Event_Locations']['fields']['branch_address_c']['labelValue']='Branch Address';

 ?>