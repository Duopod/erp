<?php
// created: 2015-09-05 16:00:50
$dictionary['anmol_marketing_campaigns']['fields']['name']['required'] = false;
$dictionary['anmol_marketing_campaigns']['fields']['name']['inline_edit'] = true;
$dictionary['anmol_marketing_campaigns']['fields']['name']['duplicate_merge'] = 'disabled';
$dictionary['anmol_marketing_campaigns']['fields']['name']['duplicate_merge_dom_value'] = '0';
$dictionary['anmol_marketing_campaigns']['fields']['name']['merge_filter'] = 'disabled';
$dictionary['anmol_marketing_campaigns']['fields']['name']['unified_search'] = false;

?>