<?php
// created: 2015-09-05 15:59:00
$dictionary['anmol_marketing_campaigns']['fields']['name_of_event_c']['inline_edit'] = '1';
$dictionary['anmol_marketing_campaigns']['fields']['name_of_event_c']['labelValue'] = 'Name of Event';

?>