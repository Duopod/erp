<?php
// created: 2015-09-05 15:49:32
$dictionary['anmol_marketing_campaigns']['fields']['campaign_type_c']['inline_edit'] = '1';
$dictionary['anmol_marketing_campaigns']['fields']['campaign_type_c']['labelValue'] = 'Campaign Type';

?>