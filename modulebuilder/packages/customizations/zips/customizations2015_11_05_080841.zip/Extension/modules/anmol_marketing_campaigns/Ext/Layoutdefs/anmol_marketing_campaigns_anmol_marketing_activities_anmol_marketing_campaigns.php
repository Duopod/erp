<?php
// created: 2015-09-05 14:48:06
$layout_defs["anmol_marketing_campaigns"]["subpanel_setup"]['anmol_marketing_campaigns_anmol_marketing_activities'] = array(
    'order' => 100,
    'module' => 'anmol_Marketing_activities',
    'subpanel_name' => 'default',
    'sort_order' => 'asc',
    'sort_by' => 'id',
    'title_key' => 'LBL_ANMOL_MARKETING_CAMPAIGNS_ANMOL_MARKETING_ACTIVITIES_FROM_ANMOL_MARKETING_ACTIVITIES_TITLE',
    'get_subpanel_data' => 'anmol_marketing_campaigns_anmol_marketing_activities',
    'top_buttons' =>
        array(
            0 =>
                array(
                    'widget_class' => 'SubPanelTopButtonQuickCreate',
                ),
            1 =>
                array(
                    'widget_class' => 'SubPanelTopSelectButton',
                    'mode' => 'MultiSelect',
                ),
        ),
);
