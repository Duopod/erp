<?php
// created: 2015-09-05 14:48:06
$dictionary["anmol_marketing_campaigns"]["fields"]["anmol_marketing_campaigns_anmol_marketing_activities"] = array(
    'name' => 'anmol_marketing_campaigns_anmol_marketing_activities',
    'type' => 'link',
    'relationship' => 'anmol_marketing_campaigns_anmol_marketing_activities',
    'source' => 'non-db',
    'module' => 'anmol_Marketing_activities',
    'bean_name' => 'anmol_Marketing_activities',
    'side' => 'right',
    'vname' => 'LBL_ANMOL_MARKETING_CAMPAIGNS_ANMOL_MARKETING_ACTIVITIES_FROM_ANMOL_MARKETING_ACTIVITIES_TITLE',
);
