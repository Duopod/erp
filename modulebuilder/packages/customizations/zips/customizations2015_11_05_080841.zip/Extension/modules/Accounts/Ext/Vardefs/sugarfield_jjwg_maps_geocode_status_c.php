<?php
// created: 2015-08-22 13:15:25
$dictionary['Account']['fields']['jjwg_maps_geocode_status_c']['inline_edit'] = 1;

?>