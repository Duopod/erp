<?php

$mod_strings = array_merge($mod_strings,
    array(
        'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => "Berechtigungsgruppen",
    )
);
?>
