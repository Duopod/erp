<?php
// created: 2015-08-22 13:15:23
$dictionary['Account']['fields']['jjwg_maps_lat_c']['inline_edit'] = 1;

?>