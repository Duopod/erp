<?php
// created: 2015-08-22 13:15:21
$dictionary['Account']['fields']['jjwg_maps_lng_c']['inline_edit'] = 1;

?>