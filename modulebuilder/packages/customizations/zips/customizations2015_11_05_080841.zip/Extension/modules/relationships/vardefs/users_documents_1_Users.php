<?php
// created: 2015-08-29 17:09:46
$dictionary["User"]["fields"]["users_documents_1"] = array(
    'name' => 'users_documents_1',
    'type' => 'link',
    'relationship' => 'users_documents_1',
    'source' => 'non-db',
    'module' => 'Documents',
    'bean_name' => 'Document',
    'side' => 'right',
    'vname' => 'LBL_USERS_DOCUMENTS_1_FROM_DOCUMENTS_TITLE',
);
