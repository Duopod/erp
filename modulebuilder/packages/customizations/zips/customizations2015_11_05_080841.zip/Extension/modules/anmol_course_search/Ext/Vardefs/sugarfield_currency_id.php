<?php
// created: 2015-09-06 19:40:50
$dictionary['anmol_course_search']['fields']['currency_id']['inline_edit'] = 1;

?>