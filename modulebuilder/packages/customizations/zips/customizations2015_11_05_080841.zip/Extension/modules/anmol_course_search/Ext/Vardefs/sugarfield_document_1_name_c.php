<?php
// created: 2015-09-08 20:47:24
$dictionary['anmol_course_search']['fields']['document_1_name_c']['inline_edit'] = '1';
$dictionary['anmol_course_search']['fields']['document_1_name_c']['labelValue'] = 'Document 1 Name';

?>