<?php
 // created: 2015-09-08 21:17:24
$dictionary['anmol_course_search']['fields']['document_6_name_c']['inline_edit']='1';
$dictionary['anmol_course_search']['fields']['document_6_name_c']['labelValue']='document 6 name';

 ?>