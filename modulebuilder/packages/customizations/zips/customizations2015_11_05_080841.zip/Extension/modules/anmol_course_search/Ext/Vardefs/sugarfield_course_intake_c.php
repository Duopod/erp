<?php
// created: 2015-09-06 19:40:38
$dictionary['anmol_course_search']['fields']['course_intake_c']['inline_edit'] = 1;

?>