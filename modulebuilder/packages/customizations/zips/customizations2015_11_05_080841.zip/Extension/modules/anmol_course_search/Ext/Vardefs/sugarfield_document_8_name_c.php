<?php
 // created: 2015-09-08 21:19:46
$dictionary['anmol_course_search']['fields']['document_8_name_c']['inline_edit']='1';
$dictionary['anmol_course_search']['fields']['document_8_name_c']['labelValue']='document 8 name';

 ?>