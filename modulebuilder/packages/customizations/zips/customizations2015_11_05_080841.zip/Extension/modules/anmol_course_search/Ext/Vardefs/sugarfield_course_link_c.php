<?php
// created: 2015-09-06 19:40:35
$dictionary['anmol_course_search']['fields']['course_link_c']['inline_edit'] = 1;
$dictionary['anmol_course_search']['fields']['course_link_c']['labelValue'] = 'Online Link';

?>