<?php
 // created: 2015-09-08 21:29:47
$dictionary['anmol_course_search']['fields']['document_15_name_c']['inline_edit']='1';
$dictionary['anmol_course_search']['fields']['document_15_name_c']['labelValue']='document 15 name';

 ?>