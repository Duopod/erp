<?php
 // created: 2015-09-08 21:15:14
$dictionary['anmol_course_search']['fields']['document_5_name_c']['inline_edit']='1';
$dictionary['anmol_course_search']['fields']['document_5_name_c']['labelValue']='document 5 name';

 ?>