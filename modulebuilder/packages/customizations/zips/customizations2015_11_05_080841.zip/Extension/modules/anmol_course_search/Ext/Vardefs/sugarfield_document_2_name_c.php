<?php
 // created: 2015-09-08 21:11:05
$dictionary['anmol_course_search']['fields']['document_2_name_c']['inline_edit']='1';
$dictionary['anmol_course_search']['fields']['document_2_name_c']['labelValue']='document 2 name';

 ?>