<?php
// created: 2015-09-06 19:40:53
$dictionary['anmol_course_search']['fields']['location_c']['inline_edit'] = 1;
$dictionary['anmol_course_search']['fields']['location_c']['labelValue'] = 'Location';

?>