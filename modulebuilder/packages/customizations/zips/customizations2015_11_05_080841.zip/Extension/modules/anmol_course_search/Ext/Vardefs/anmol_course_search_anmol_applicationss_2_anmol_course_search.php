<?php
// created: 2015-09-08 17:45:17
$dictionary["anmol_course_search"]["fields"]["anmol_course_search_anmol_applicationss_2"] = array(
    'name' => 'anmol_course_search_anmol_applicationss_2',
    'type' => 'link',
    'relationship' => 'anmol_course_search_anmol_applicationss_2',
    'source' => 'non-db',
    'module' => 'anmol_Applicationss',
    'bean_name' => 'anmol_Applicationss',
    'side' => 'right',
    'vname' => 'LBL_ANMOL_COURSE_SEARCH_ANMOL_APPLICATIONSS_2_FROM_ANMOL_APPLICATIONSS_TITLE',
);
