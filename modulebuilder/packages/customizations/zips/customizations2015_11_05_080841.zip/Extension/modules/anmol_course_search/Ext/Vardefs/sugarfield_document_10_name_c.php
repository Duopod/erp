<?php
 // created: 2015-09-08 21:24:01
$dictionary['anmol_course_search']['fields']['document_10_name_c']['inline_edit']='1';
$dictionary['anmol_course_search']['fields']['document_10_name_c']['labelValue']='document 10 name';

 ?>