<?php
// created: 2015-09-06 11:36:23
$mod_strings['LBL_NAME'] = 'Course Name';
$mod_strings['LBL_LOCATION'] = 'Location';
$mod_strings['LBL_COURSE_INTAKE'] = 'Course Intake';
$mod_strings['LBL_COURSE_DURATION'] = 'Course Duration';
$mod_strings['LBL_COURSE_LEVEL'] = 'Course Level';
$mod_strings['LBL_IELTS_REQUIRED'] = 'IELTS Requires?';
$mod_strings['LBL_MIN_IELTS_REQUIREMENT'] = 'Minimum Score Required';
$mod_strings['LBL_MIN_ACADEMIN_REQUIREMENT'] = 'Minimum Academic Requirement';
$mod_strings['LBL_TOTAL_FEE'] = 'Total Fee';
$mod_strings['LBL_REPRESENTED_BY_US'] = 'SIEC Represents?';
$mod_strings['LBL_COURSE_LINK'] = 'Online Link';

?>
