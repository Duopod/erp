<?php
// created: 2015-09-06 19:40:43
$dictionary['anmol_course_search']['fields']['min_ielts_requirement_c']['inline_edit'] = 1;

?>