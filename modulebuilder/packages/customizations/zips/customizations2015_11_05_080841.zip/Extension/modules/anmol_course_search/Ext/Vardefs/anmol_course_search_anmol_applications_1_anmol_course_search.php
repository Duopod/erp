<?php
// created: 2015-08-28 22:49:14
$dictionary["anmol_course_search"]["fields"]["anmol_course_search_anmol_applications_1"] = array(
    'name' => 'anmol_course_search_anmol_applications_1',
    'type' => 'link',
    'relationship' => 'anmol_course_search_anmol_applications_1',
    'source' => 'non-db',
    'module' => 'anmol_Applications',
    'bean_name' => 'anmol_Applications',
    'side' => 'right',
    'vname' => 'LBL_ANMOL_COURSE_SEARCH_ANMOL_APPLICATIONS_1_FROM_ANMOL_APPLICATIONS_TITLE',
);
