<?php
// created: 2015-09-06 19:40:51
$dictionary['anmol_course_search']['fields']['represented_by_us_c']['inline_edit'] = 1;

?>