<?php
// created: 2015-09-06 19:40:45
$dictionary['anmol_course_search']['fields']['min_academin_requirement_c']['inline_edit'] = 1;

?>