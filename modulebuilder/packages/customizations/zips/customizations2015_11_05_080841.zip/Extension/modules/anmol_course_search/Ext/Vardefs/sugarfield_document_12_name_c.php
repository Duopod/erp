<?php
 // created: 2015-09-08 21:25:43
$dictionary['anmol_course_search']['fields']['document_12_name_c']['inline_edit']='1';
$dictionary['anmol_course_search']['fields']['document_12_name_c']['labelValue']='document 12 name';

 ?>