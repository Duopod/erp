<?php
// created: 2015-09-06 19:40:48
$dictionary['anmol_course_search']['fields']['total_fee_c']['inline_edit'] = 1;
$dictionary['anmol_course_search']['fields']['total_fee_c']['options'] = 'numeric_range_search_dom';
$dictionary['anmol_course_search']['fields']['total_fee_c']['labelValue'] = 'Total Fee';
$dictionary['anmol_course_search']['fields']['total_fee_c']['enable_range_search'] = '1';

?>