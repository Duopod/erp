<?php
// created: 2015-09-06 19:40:37
$dictionary['anmol_course_search']['fields']['course_level_c']['inline_edit'] = 1;

?>