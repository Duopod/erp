<?php
// created: 2015-08-28 19:54:23
$dictionary['Lead']['fields']['last_name']['required'] = false;
$dictionary['Lead']['fields']['last_name']['inline_edit'] = true;
$dictionary['Lead']['fields']['last_name']['comments'] = 'Last name of the contact';
$dictionary['Lead']['fields']['last_name']['merge_filter'] = 'disabled';

?>