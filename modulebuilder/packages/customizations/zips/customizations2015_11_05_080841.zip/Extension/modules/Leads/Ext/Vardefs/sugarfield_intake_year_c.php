<?php
// created: 2015-09-06 20:43:58
$dictionary['Lead']['fields']['intake_year_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['intake_year_c']['labelValue'] = 'Intake Year';

?>