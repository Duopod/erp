<?php
// created: 2015-09-06 19:06:32
$dictionary['Lead']['fields']['last_year_of_qualification_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['last_year_of_qualification_c']['labelValue'] = 'Last Year Of Qualification';

?>