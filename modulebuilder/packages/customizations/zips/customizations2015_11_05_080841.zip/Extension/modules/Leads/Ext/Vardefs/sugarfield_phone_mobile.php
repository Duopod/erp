<?php
// created: 2015-09-06 21:12:43
$dictionary['Lead']['fields']['phone_mobile']['inline_edit'] = '';
$dictionary['Lead']['fields']['phone_mobile']['comments'] = 'Mobile phone number of the contact';
$dictionary['Lead']['fields']['phone_mobile']['merge_filter'] = 'disabled';
$dictionary['Lead']['fields']['phone_mobile']['required'] = true;

?>