<?php
 // created: 2015-09-19 11:13:02
$dictionary['Lead']['fields']['course_level_preference_c']['inline_edit']='1';
$dictionary['Lead']['fields']['course_level_preference_c']['labelValue']='Course Level Preference';

 ?>