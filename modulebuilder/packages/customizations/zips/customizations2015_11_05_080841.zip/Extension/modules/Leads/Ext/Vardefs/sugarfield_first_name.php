<?php
// created: 2015-08-28 19:58:43
$dictionary['Lead']['fields']['first_name']['required'] = true;
$dictionary['Lead']['fields']['first_name']['inline_edit'] = true;
$dictionary['Lead']['fields']['first_name']['comments'] = 'First name of the contact';
$dictionary['Lead']['fields']['first_name']['merge_filter'] = 'disabled';

?>