<?php
// created: 2015-09-06 20:31:41
$dictionary['Lead']['fields']['country_interested_in_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['country_interested_in_c']['labelValue'] = 'Country';

?>