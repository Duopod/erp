<?php
// created: 2015-09-06 23:38:46
$dictionary['Lead']['fields']['experience_in_years_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['experience_in_years_c']['labelValue'] = 'Years';

?>