<?php
// created: 2015-09-06 20:20:48
$dictionary['Lead']['fields']['stream_interest_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['stream_interest_c']['labelValue'] = 'Course Stream';

?>