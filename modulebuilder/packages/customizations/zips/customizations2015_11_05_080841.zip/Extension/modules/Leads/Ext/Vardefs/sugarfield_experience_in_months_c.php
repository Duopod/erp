<?php
// created: 2015-09-06 19:29:55
$dictionary['Lead']['fields']['experience_in_months_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['experience_in_months_c']['labelValue'] = 'Months';

?>