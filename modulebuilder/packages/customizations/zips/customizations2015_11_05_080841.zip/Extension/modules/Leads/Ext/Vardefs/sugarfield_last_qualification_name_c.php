<?php
// created: 2015-09-06 19:17:44
$dictionary['Lead']['fields']['last_qualification_name_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['last_qualification_name_c']['labelValue'] = 'Last Qualification Name';

?>