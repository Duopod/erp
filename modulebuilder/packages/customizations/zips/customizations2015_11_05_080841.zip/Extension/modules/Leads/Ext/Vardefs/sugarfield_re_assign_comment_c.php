<?php
 // created: 2015-09-15 23:01:31
$dictionary['Lead']['fields']['re_assign_comment_c']['inline_edit']='1';
$dictionary['Lead']['fields']['re_assign_comment_c']['labelValue']='Re-Assign Comment';

 ?>