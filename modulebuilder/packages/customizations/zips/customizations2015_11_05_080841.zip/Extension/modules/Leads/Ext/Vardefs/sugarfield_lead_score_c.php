<?php
// created: 2015-09-06 18:50:47
$dictionary['Lead']['fields']['lead_score_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['lead_score_c']['labelValue'] = 'Lead Score';

?>