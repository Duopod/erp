<?php
// created: 2015-09-05 13:32:15
$dictionary['Lead']['fields']['lead_source']['inline_edit'] = true;
$dictionary['Lead']['fields']['lead_source']['comments'] = 'Lead source (ex: Web, print)';
$dictionary['Lead']['fields']['lead_source']['merge_filter'] = 'disabled';
$dictionary['Lead']['fields']['lead_source']['required'] = false;

?>