<?php
// created: 2015-09-06 19:00:32
$dictionary['Lead']['fields']['last_qualification_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['last_qualification_c']['labelValue'] = 'Last Qualification';

?>