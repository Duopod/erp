<?php
 // created: 2015-09-15 22:08:42
$dictionary['Lead']['fields']['follow_up_date_c']['inline_edit']='';
$dictionary['Lead']['fields']['follow_up_date_c']['options']='date_range_search_dom';
$dictionary['Lead']['fields']['follow_up_date_c']['labelValue']='Follow up date';
$dictionary['Lead']['fields']['follow_up_date_c']['enable_range_search']='1';

 ?>