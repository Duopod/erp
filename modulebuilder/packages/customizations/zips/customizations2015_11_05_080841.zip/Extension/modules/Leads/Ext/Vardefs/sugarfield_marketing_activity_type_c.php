<?php
// created: 2015-09-06 17:48:39
$dictionary['Lead']['fields']['marketing_activity_type_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['marketing_activity_type_c']['labelValue'] = 'Source';

?>