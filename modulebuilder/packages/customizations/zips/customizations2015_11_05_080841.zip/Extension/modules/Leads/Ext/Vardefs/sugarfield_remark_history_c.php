<?php
// created: 2015-09-07 13:30:40
$dictionary['Lead']['fields']['remark_history_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['remark_history_c']['labelValue'] = 'Remark History';

?>