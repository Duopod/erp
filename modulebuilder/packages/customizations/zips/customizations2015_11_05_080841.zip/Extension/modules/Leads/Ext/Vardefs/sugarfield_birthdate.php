<?php
// created: 2015-09-05 12:20:12
$dictionary['Lead']['fields']['birthdate']['required'] = true;
$dictionary['Lead']['fields']['birthdate']['inline_edit'] = true;
$dictionary['Lead']['fields']['birthdate']['massupdate'] = '1';
$dictionary['Lead']['fields']['birthdate']['options'] = 'date_range_search_dom';
$dictionary['Lead']['fields']['birthdate']['comments'] = 'The birthdate of the contact';
$dictionary['Lead']['fields']['birthdate']['merge_filter'] = 'disabled';
$dictionary['Lead']['fields']['birthdate']['enable_range_search'] = '1';

?>