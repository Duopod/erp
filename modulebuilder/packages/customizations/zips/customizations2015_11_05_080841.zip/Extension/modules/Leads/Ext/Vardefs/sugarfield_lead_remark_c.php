<?php
// created: 2015-09-07 13:31:34
$dictionary['Lead']['fields']['lead_remark_c']['inline_edit'] = '1';
$dictionary['Lead']['fields']['lead_remark_c']['labelValue'] = 'Remark';

?>