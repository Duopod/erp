<?php
// created: 2015-08-28 19:59:34
$dictionary['Lead']['fields']['email1']['required'] = true;
$dictionary['Lead']['fields']['email1']['inline_edit'] = true;
$dictionary['Lead']['fields']['email1']['merge_filter'] = 'disabled';

?>