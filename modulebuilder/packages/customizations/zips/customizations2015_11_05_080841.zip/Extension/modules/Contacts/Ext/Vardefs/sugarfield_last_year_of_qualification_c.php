<?php
// created: 2015-09-06 23:46:48
$dictionary['Contact']['fields']['last_year_of_qualification_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['last_year_of_qualification_c']['labelValue'] = 'Last Year of Qualification';

?>