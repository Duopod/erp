<?php
// created: 2015-09-21 22:38:54
$dictionary["Contact"]["fields"]["contacts_anmol_application_stages_1"] = array (
  'name' => 'contacts_anmol_application_stages_1',
  'type' => 'link',
  'relationship' => 'contacts_anmol_application_stages_1',
  'source' => 'non-db',
  'module' => 'anmol_application_stages',
  'bean_name' => 'anmol_application_stages',
  'side' => 'right',
  'vname' => 'LBL_CONTACTS_ANMOL_APPLICATION_STAGES_1_FROM_ANMOL_APPLICATION_STAGES_TITLE',
);
