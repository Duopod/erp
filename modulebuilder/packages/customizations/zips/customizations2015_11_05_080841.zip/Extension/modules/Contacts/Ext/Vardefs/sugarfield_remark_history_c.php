<?php
// created: 2015-09-07 19:02:05
$dictionary['Contact']['fields']['remark_history_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['remark_history_c']['labelValue'] = 'History';

?>