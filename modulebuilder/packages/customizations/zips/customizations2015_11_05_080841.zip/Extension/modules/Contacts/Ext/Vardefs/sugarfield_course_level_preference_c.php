<?php
// created: 2015-09-06 23:35:39
$dictionary['Contact']['fields']['course_level_preference_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['course_level_preference_c']['labelValue'] = 'Course Level Preference';

?>