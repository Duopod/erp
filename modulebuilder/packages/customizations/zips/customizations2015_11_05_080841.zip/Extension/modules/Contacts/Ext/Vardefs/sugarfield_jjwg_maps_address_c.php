<?php
// created: 2015-08-22 13:15:36
$dictionary['Contact']['fields']['jjwg_maps_address_c']['inline_edit'] = 1;

?>