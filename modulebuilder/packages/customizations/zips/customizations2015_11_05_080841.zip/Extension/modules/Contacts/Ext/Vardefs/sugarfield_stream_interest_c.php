<?php
// created: 2015-09-06 23:50:29
$dictionary['Contact']['fields']['stream_interest_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['stream_interest_c']['labelValue'] = 'Course Stream Preference';

?>