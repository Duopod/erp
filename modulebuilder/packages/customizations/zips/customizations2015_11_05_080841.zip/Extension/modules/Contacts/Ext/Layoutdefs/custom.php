<?php

$layout_defs['Contacts']['subpanel_setup']['documents'] = array();
$layout_defs['Contacts']['subpanel_setup']['history'] = array();
$layout_defs['Contacts']['subpanel_setup']['activities'] = array();
$layout_defs['Contacts']['subpanel_setup']['campaigns'] = array();
$layout_defs['Contacts']['subpanel_setup']['cases'] = array();
$layout_defs['Contacts']['subpanel_setup']['bugs'] = array();
$layout_defs['Contacts']['subpanel_setup']['project'] = array();
//$layout_defs['Contacts']['subpanel_setup']['contacts'] = array();
$layout_defs['Contacts']['subpanel_setup']['opportunities'] = array();
$layout_defs['Contacts']['subpanel_setup']['invoices'] = array();

//$layout_defs['Contacts']['subpanel_setup']['contracts'] = array ();


?>