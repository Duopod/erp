<?php
// created: 2015-09-07 20:26:16
$dictionary['Contact']['fields']['contact_address_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['contact_address_c']['labelValue'] = 'Address:';

?>