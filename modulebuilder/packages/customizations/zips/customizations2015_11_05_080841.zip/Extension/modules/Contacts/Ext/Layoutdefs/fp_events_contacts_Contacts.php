<?php
// created: 2013-04-15 12:13:27
$layout_defs["Contacts"]["subpanel_setup"]['fp_events_contacts'] = array(
    'order' => 100,
    'module' => 'FP_events',
    'subpanel_name' => 'default',
    'sort_order' => 'asc',
    'sort_by' => 'id',
    'title_key' => 'LBL_FP_EVENTS_CONTACTS_FROM_FP_EVENTS_TITLE',
    'get_subpanel_data' => 'fp_events_contacts',
    'top_buttons' =>
        array(
            0 =>
                array(
                    'widget_class' => 'SubPanelTopButtonQuickCreate',
                ),
            1 =>
                array(
                    'widget_class' => 'SubPanelTopSelectButton',
                    'mode' => 'MultiSelect',
                ),
        ),
);
