<?php
// created: 2015-09-07 20:22:03
$dictionary['Contact']['fields']['state_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['state_c']['labelValue'] = 'State';

?>