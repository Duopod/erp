<?php
// created: 2015-09-08 17:27:28
$dictionary["Contact"]["fields"]["contacts_anmol_applicationss_1"] = array(
    'name' => 'contacts_anmol_applicationss_1',
    'type' => 'link',
    'relationship' => 'contacts_anmol_applicationss_1',
    'source' => 'non-db',
    'module' => 'anmol_Applicationss',
    'bean_name' => 'anmol_Applicationss',
    'side' => 'right',
    'vname' => 'LBL_CONTACTS_ANMOL_APPLICATIONSS_1_FROM_ANMOL_APPLICATIONSS_TITLE',
);
