<?php
// created: 2015-09-06 23:42:17
$dictionary['Contact']['fields']['intake_year_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['intake_year_c']['labelValue'] = 'Intake Year';

?>