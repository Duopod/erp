<?php
// created: 2013-04-15 12:13:27
$dictionary["Contact"]["fields"]["fp_events_contacts"] = array(
    'name' => 'fp_events_contacts',
    'type' => 'link',
    'relationship' => 'fp_events_contacts',
    'source' => 'non-db',
    'vname' => 'LBL_FP_EVENTS_CONTACTS_FROM_FP_EVENTS_TITLE',
);
