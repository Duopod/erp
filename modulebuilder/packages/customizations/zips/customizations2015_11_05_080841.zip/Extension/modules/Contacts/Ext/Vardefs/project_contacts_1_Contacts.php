<?php
// created: 2014-06-24 15:48:56
$dictionary["Contact"]["fields"]["project_contacts_1"] = array(
    'name' => 'project_contacts_1',
    'type' => 'link',
    'relationship' => 'project_contacts_1',
    'source' => 'non-db',
    'module' => 'Project',
    'bean_name' => 'Project',
    'vname' => 'LBL_PROJECT_CONTACTS_1_FROM_PROJECT_TITLE',
);
