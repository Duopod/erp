<?php

$layout_defs["Contacts"]["subpanel_setup"]["contacts_anmol_applicationss_1"]["top_buttons"] = array(
    array(
        'widget_class' => 'SubPanelTopCreateButton',
    ),
    array(
        'widget_class' => 'SubPanelTopSelectButton',
        'mode' => 'MultiSelect',
    ),
);

// ehe code hai << Full Form wala! oh jehda article aa oh ki keh reah  ?
// oh v ehi keh reha. hor tarike naal
