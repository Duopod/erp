<?php
// created: 2015-09-06 23:41:11
$dictionary['Contact']['fields']['intake_month_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['intake_month_c']['labelValue'] = 'Intake Month';

?>