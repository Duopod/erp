<?php
 // created: 2015-10-19 09:58:39
$dictionary['Contact']['fields']['passport_number_c']['inline_edit']='';
$dictionary['Contact']['fields']['passport_number_c']['labelValue']='Passport number';

 ?>