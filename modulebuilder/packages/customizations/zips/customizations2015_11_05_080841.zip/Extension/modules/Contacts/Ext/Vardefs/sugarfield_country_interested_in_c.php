<?php
// created: 2015-09-06 22:01:19
$dictionary['Contact']['fields']['country_interested_in_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['country_interested_in_c']['labelValue'] = 'Country Interested in';

?>