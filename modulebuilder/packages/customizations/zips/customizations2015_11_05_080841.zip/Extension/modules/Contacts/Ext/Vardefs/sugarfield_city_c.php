<?php
// created: 2015-09-07 20:21:06
$dictionary['Contact']['fields']['city_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['city_c']['labelValue'] = 'City';

?>