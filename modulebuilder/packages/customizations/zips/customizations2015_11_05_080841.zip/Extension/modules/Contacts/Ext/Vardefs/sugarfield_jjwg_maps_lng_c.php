<?php
// created: 2015-08-22 13:15:33
$dictionary['Contact']['fields']['jjwg_maps_lng_c']['inline_edit'] = 1;

?>