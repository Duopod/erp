<?php
// created: 2015-09-06 23:37:05
$dictionary['Contact']['fields']['experience_in_months_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['experience_in_months_c']['labelValue'] = 'Months';

?>