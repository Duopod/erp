<?php
// created: 2015-09-06 23:43:54
$dictionary['Contact']['fields']['last_qualification_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['last_qualification_c']['labelValue'] = 'Last Qualification';

?>