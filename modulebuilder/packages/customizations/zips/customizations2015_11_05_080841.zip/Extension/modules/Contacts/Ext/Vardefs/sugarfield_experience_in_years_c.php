<?php
// created: 2015-09-06 23:39:29
$dictionary['Contact']['fields']['experience_in_years_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['experience_in_years_c']['labelValue'] = 'Years';

?>