<?php
// created: 2015-09-06 23:48:59
$dictionary['Contact']['fields']['marketing_activity_type_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['marketing_activity_type_c']['labelValue'] = 'Source';

?>