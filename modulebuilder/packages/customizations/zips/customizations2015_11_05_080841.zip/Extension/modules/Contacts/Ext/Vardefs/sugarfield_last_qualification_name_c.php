<?php
// created: 2015-09-06 23:45:34
$dictionary['Contact']['fields']['last_qualification_name_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['last_qualification_name_c']['labelValue'] = 'Last Qualification Name';

?>