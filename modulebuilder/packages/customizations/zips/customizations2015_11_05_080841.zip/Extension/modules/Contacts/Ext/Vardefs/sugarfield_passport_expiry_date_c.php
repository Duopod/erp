<?php
 // created: 2015-10-19 10:03:16
$dictionary['Contact']['fields']['passport_expiry_date_c']['inline_edit']='1';
$dictionary['Contact']['fields']['passport_expiry_date_c']['options']='date_range_search_dom';
$dictionary['Contact']['fields']['passport_expiry_date_c']['labelValue']='Passport Expiry Date';
$dictionary['Contact']['fields']['passport_expiry_date_c']['enable_range_search']='1';

 ?>