<?php
// created: 2015-09-06 23:47:50
$dictionary['Contact']['fields']['lead_score_c']['inline_edit'] = '1';
$dictionary['Contact']['fields']['lead_score_c']['labelValue'] = 'Lead Score';

?>