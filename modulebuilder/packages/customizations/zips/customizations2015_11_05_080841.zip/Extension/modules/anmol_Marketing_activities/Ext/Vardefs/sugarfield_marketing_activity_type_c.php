<?php
// created: 2015-09-05 19:17:51
$dictionary['anmol_Marketing_activities']['fields']['marketing_activity_type_c']['inline_edit'] = '1';
$dictionary['anmol_Marketing_activities']['fields']['marketing_activity_type_c']['labelValue'] = 'Marketing Activity Type';

?>