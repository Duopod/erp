<?php
// created: 2015-08-29 16:37:35
$dictionary['Document']['fields']['active_date']['required'] = false;
$dictionary['Document']['fields']['active_date']['inline_edit'] = true;
$dictionary['Document']['fields']['active_date']['merge_filter'] = 'disabled';
$dictionary['Document']['fields']['active_date']['enable_range_search'] = false;

?>