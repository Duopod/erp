<?php
// created: 2015-08-29 17:04:07
$dictionary["Document"]["fields"]["documents_users_1"] = array(
    'name' => 'documents_users_1',
    'type' => 'link',
    'relationship' => 'documents_users_1',
    'source' => 'non-db',
    'module' => 'Users',
    'bean_name' => 'User',
    'side' => 'right',
    'vname' => 'LBL_DOCUMENTS_USERS_1_FROM_USERS_TITLE',
);
