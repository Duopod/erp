<?php
// created: 2015-08-22 13:16:00
$dictionary['Project']['fields']['jjwg_maps_lng_c']['inline_edit'] = 1;

?>