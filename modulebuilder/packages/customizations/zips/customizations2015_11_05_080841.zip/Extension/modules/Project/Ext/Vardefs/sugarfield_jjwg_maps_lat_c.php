<?php
// created: 2015-08-22 13:16:01
$dictionary['Project']['fields']['jjwg_maps_lat_c']['inline_edit'] = 1;

?>