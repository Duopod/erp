<?php
// created: 2014-06-25 23:55:39
$layout_defs["Project"]["subpanel_setup"]['am_projectholidays_project'] = array(
    'order' => 100,
    'module' => 'AM_ProjectHolidays',
    'subpanel_name' => 'default',
    'sort_order' => 'asc',
    'sort_by' => 'id',
    'title_key' => 'LBL_AM_PROJECTHOLIDAYS_PROJECT_FROM_AM_PROJECTHOLIDAYS_TITLE',
    'get_subpanel_data' => 'am_projectholidays_project',
    'top_buttons' =>
        array(
            0 =>
                array(
                    'widget_class' => 'SubPanelTopCreateButton',
                ),
        ),
);
