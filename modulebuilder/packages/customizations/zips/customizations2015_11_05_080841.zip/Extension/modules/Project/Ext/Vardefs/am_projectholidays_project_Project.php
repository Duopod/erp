<?php
// created: 2014-06-25 23:55:39
$dictionary["Project"]["fields"]["am_projectholidays_project"] = array(
    'name' => 'am_projectholidays_project',
    'type' => 'link',
    'relationship' => 'am_projectholidays_project',
    'source' => 'non-db',
    'module' => 'AM_ProjectHolidays',
    'bean_name' => 'AM_ProjectHolidays',
    'side' => 'right',
    'vname' => 'LBL_AM_PROJECTHOLIDAYS_PROJECT_FROM_AM_PROJECTHOLIDAYS_TITLE',
);
