<?php
// created: 2014-06-24 15:48:56
$dictionary["Project"]["fields"]["project_contacts_1"] = array(
    'name' => 'project_contacts_1',
    'type' => 'link',
    'relationship' => 'project_contacts_1',
    'source' => 'non-db',
    'module' => 'Contacts',
    'bean_name' => 'Contact',
    'vname' => 'LBL_PROJECT_CONTACTS_1_FROM_CONTACTS_TITLE',
);
