<?php
// created: 2015-08-22 13:16:04
$dictionary['Prospect']['fields']['jjwg_maps_lat_c']['inline_edit'] = 1;

?>