<?php
// created: 2015-09-08 17:52:07
$dictionary['anmol_Applicationss']['fields']['uni_name_c']['inline_edit'] = '1';
$dictionary['anmol_Applicationss']['fields']['uni_name_c']['labelValue'] = 'University';

?>