<?php
// created: 2015-09-08 17:50:18
$dictionary['anmol_Applicationss']['fields']['name']['required'] = false;
$dictionary['anmol_Applicationss']['fields']['name']['inline_edit'] = true;
$dictionary['anmol_Applicationss']['fields']['name']['duplicate_merge'] = 'disabled';
$dictionary['anmol_Applicationss']['fields']['name']['duplicate_merge_dom_value'] = '0';
$dictionary['anmol_Applicationss']['fields']['name']['merge_filter'] = 'disabled';
$dictionary['anmol_Applicationss']['fields']['name']['unified_search'] = false;

?>