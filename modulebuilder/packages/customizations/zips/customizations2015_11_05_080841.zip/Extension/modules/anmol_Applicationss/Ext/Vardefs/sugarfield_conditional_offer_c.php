<?php
 // created: 2015-09-21 08:21:42
$dictionary['anmol_Applicationss']['fields']['conditional_offer_c']['inline_edit']='';
$dictionary['anmol_Applicationss']['fields']['conditional_offer_c']['labelValue']='Apply for a Conditional Offer';

 ?>