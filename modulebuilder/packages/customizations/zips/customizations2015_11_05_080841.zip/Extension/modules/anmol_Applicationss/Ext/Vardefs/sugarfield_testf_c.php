<?php
 // created: 2015-09-23 01:54:31
$dictionary['anmol_Applicationss']['fields']['testf_c']['inline_edit']='';
$dictionary['anmol_Applicationss']['fields']['testf_c']['labelValue']='testf';

 ?>