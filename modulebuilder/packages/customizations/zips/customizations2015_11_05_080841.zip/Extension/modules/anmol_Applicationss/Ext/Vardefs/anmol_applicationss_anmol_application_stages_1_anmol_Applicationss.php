<?php
// created: 2015-09-16 13:05:15
$dictionary["anmol_Applicationss"]["fields"]["anmol_applicationss_anmol_application_stages_1"] = array (
  'name' => 'anmol_applicationss_anmol_application_stages_1',
  'type' => 'link',
  'relationship' => 'anmol_applicationss_anmol_application_stages_1',
  'source' => 'non-db',
  'module' => 'anmol_application_stages',
  'bean_name' => 'anmol_application_stages',
  'side' => 'right',
  'vname' => 'LBL_ANMOL_APPLICATIONSS_ANMOL_APPLICATION_STAGES_1_FROM_ANMOL_APPLICATION_STAGES_TITLE',
);
