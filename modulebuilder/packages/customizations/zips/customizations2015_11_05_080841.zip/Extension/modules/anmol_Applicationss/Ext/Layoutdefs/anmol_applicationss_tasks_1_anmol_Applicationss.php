<?php
 // created: 2015-09-22 22:57:00
$layout_defs["anmol_Applicationss"]["subpanel_setup"]['anmol_applicationss_tasks_1'] = array (
  'order' => 100,
  'module' => 'Tasks',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANMOL_APPLICATIONSS_TASKS_1_FROM_TASKS_TITLE',
  'get_subpanel_data' => 'anmol_applicationss_tasks_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
