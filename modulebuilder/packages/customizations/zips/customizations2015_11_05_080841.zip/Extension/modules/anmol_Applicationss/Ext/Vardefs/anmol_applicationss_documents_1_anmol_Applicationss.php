<?php
// created: 2015-09-08 17:22:07
$dictionary["anmol_Applicationss"]["fields"]["anmol_applicationss_documents_1"] = array(
    'name' => 'anmol_applicationss_documents_1',
    'type' => 'link',
    'relationship' => 'anmol_applicationss_documents_1',
    'source' => 'non-db',
    'module' => 'Documents',
    'bean_name' => 'Document',
    'side' => 'right',
    'vname' => 'LBL_ANMOL_APPLICATIONSS_DOCUMENTS_1_FROM_DOCUMENTS_TITLE',
);
