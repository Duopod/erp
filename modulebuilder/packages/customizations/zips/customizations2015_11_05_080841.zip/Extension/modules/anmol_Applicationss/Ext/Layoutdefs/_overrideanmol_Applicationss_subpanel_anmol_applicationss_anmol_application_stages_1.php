<?php
//auto-generated file DO NOT EDIT
$layout_defs['anmol_Applicationss']['subpanel_setup']['anmol_applicationss_anmol_application_stages_1']['override_subpanel_name'] = 'anmol_Applicationss_subpanel_anmol_applicationss_anmol_application_stages_1';
?>