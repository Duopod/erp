<?php
 // created: 2015-09-14 01:14:39
$dictionary['anmol_Applicationss']['fields']['filename']['required']=true;
$dictionary['anmol_Applicationss']['fields']['filename']['inline_edit']=true;
$dictionary['anmol_Applicationss']['fields']['filename']['importable']='true';
$dictionary['anmol_Applicationss']['fields']['filename']['merge_filter']='disabled';
$dictionary['anmol_Applicationss']['fields']['filename']['audited']=true;

 ?>