<?php
 // created: 2015-09-21 08:33:28
$dictionary['anmol_Applicationss']['fields']['unchecked_docs_c']['inline_edit']='';
$dictionary['anmol_Applicationss']['fields']['unchecked_docs_c']['labelValue']='Unchecked Docs';

 ?>