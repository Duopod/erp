<?php
 // created: 2015-09-16 13:05:15
$layout_defs["anmol_Applicationss"]["subpanel_setup"]['anmol_applicationss_anmol_application_stages_1'] = array (
  'order' => 100,
  'module' => 'anmol_application_stages',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ANMOL_APPLICATIONSS_ANMOL_APPLICATION_STAGES_1_FROM_ANMOL_APPLICATION_STAGES_TITLE',
  'get_subpanel_data' => 'anmol_applicationss_anmol_application_stages_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
