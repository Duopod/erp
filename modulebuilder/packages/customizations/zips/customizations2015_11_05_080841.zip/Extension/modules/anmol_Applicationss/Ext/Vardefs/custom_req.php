<?php
/**
 * Created by PhpStorm.
 * User: andy
 * Date: 14-09-2015
 * Time: 02:08
 */


$dictionary['anmol_Applicationss']['fields']['anmol_course_search_anmol_applicationss_2_name']['required'] = true;  /// Making it Required
